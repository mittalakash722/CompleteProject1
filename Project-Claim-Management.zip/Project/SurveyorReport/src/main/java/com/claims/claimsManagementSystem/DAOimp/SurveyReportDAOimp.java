package com.claims.claimsManagementSystem.DAOimp;

import com.claims.claimsManagementSystem.DTO.SurveyReportDTO;
import com.claims.claimsManagementSystem.exceptions.CustomException;
import com.claims.claimsManagementSystem.microserviceCRUD.ClaimMicroservice;
import org.springframework.beans.factory.annotation.Autowired;

import com.claims.claimsManagementSystem.DAO.SurveyReportDAO;
import com.claims.claimsManagementSystem.repo.SurveyRepo;
import com.claims.claimsManagementSystem.surveyReport.SurveyReport;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

//Java class that performs some service
@Service
public class SurveyReportDAOimp implements SurveyReportDAO {
	@Autowired
	SurveyRepo repo;

	@Autowired
	ClaimMicroservice claimMicroservice;

	@Override
	// Method to insert a survey report
	public SurveyReport SurveyInsert(SurveyReportDTO surveyReportDTO) throws CustomException {

		if (surveyReportDTO.getPartsCost() > surveyReportDTO.getLabourCharges()) {


			int amt =new SurveyReportDAOimp().calculateAmount(surveyReportDTO.getClaimID(), new SurveyReportDAOimp().toEntity(surveyReportDTO));

			surveyReportDTO.setTotalAmount(amt);

			claimMicroservice.updateAmnt(surveyReportDTO.getClaimID(), surveyReportDTO.getTotalAmount());

			SurveyReport  surveyReport=new SurveyReportDAOimp().toEntity(surveyReportDTO);

			return repo.save(surveyReport);

		}
		else {
			throw  new CustomException("parts cosţs should be greater than labou cost");
		}

	}

	// Method to get a survey report by ID
	public SurveyReportDTO getSurveyById(String claimId) throws CustomException {
		SurveyReport surveyReport=repo.findSurveyReportByClaimId(claimId);
		if (surveyReport==null)
		{
			throw new CustomException("No Survey Report Exist!");
		}
		return new SurveyReportDAOimp().toDTO(surveyReport);
	}



	// Method to update a survey report
	public SurveyReport updateSurvey(String claimId, SurveyReportDTO surveyReportDTO) throws CustomException {

		SurveyReport updateReport = repo.findSurveyReportByClaimId(claimId);
		if (updateReport==null)
		{
			throw new CustomException("no Report Exist!");
		}
		if (surveyReportDTO.getPolicyNo()!=null)
		{
			updateReport.setPolicyNo(surveyReportDTO.getPolicyNo());
		}
		if(surveyReportDTO.getLabourCharges()!=0)
		{
			updateReport.setLabourCharges(surveyReportDTO.getLabourCharges());
		}
		if (surveyReportDTO.getPartsCost()!=0){
			updateReport.setPartsCost(surveyReportDTO.getPartsCost());
		}
		if (surveyReportDTO.getDepreciationCost()!=0)
		{
			updateReport.setDepreciationCost(surveyReportDTO.getDepreciationCost());
		}

		updateReport.setTotalamount(new SurveyReportDAOimp().calculateAmount(claimId,updateReport));
		claimMicroservice.updateAmnt(updateReport.getClaimId(), updateReport.getTotalamount());

		return repo.save(updateReport);

	}
	public SurveyReport toEntity(SurveyReportDTO surveyReportDTO)
	{
		SurveyReport surveyReport =new SurveyReport();
		surveyReport.setClaimId(surveyReportDTO.getClaimID());
		surveyReport.setPolicyNo(surveyReportDTO.getPolicyNo());
		surveyReport.setPolicyclass(surveyReportDTO.getPolicyClass());
		surveyReport.setLabourCharges(surveyReportDTO.getLabourCharges());
		surveyReport.setDepreciationCost(surveyReportDTO.getDepreciationCost());
		surveyReport.setPartsCost(surveyReportDTO.getPartsCost());
		surveyReport.setTotalamount(surveyReportDTO.getTotalAmount());
		return surveyReport;
	}
	public SurveyReportDTO toDTO(SurveyReport surveyReport)
	{
		SurveyReportDTO surveyReportDTO =new SurveyReportDTO();
		surveyReportDTO.setClaimID(surveyReport.getClaimId());
		surveyReportDTO.setPolicyNo(surveyReport.getPolicyNo());
		surveyReportDTO.setPolicyClass(surveyReport.getPolicyclass());
		surveyReportDTO.setLabourCharges(surveyReport.getLabourCharges());
		surveyReportDTO.setDepreciationCost(surveyReport.getDepreciationCost());
		surveyReportDTO.setPartsCost(surveyReport.getPartsCost());
		surveyReportDTO.setTotalAmount(surveyReport.getTotalamount());
		return surveyReportDTO;
	}
	int calculateAmount(String claimId,SurveyReport surveyReport)
	{

		LocalDate currentDate = LocalDate.now();
		int currentYear = currentDate.getYear();
		int age=currentYear-Integer.parseInt(claimId.substring(claimId.length()-4));

		if (age>=0 && age<5)
		{
			surveyReport.setPolicyclass(500);
		}
		else if(age>=5 && age<10)
		{
			surveyReport.setPolicyclass(1500);
		}
		else if (age>=10)
		{
			surveyReport.setPolicyclass(5000);
		}
		return surveyReport.getLabourCharges() + surveyReport.getPartsCost() - surveyReport.getDepreciationCost()- surveyReport.getPolicyclass();

	}

}
