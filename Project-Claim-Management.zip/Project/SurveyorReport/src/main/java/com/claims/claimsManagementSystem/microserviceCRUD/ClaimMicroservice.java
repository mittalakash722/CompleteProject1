package com.claims.claimsManagementSystem.microserviceCRUD;

import com.claims.claimsManagementSystem.DTO.ClaimDetailsDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

@FeignClient("INSURANCECOMPANY")
public interface ClaimMicroservice {

    @PutMapping("/api/claims/{claimId}/{amnt}/update")
    ResponseEntity updateAmnt(@PathVariable String claimId,@PathVariable int amnt);
}
