package com.claims.claimsManagementSystem.surveyReport;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.PositiveOrZero;
import java.util.Objects;


// Class mapped to a Database
@Entity
@Table(name = "SurveyReport")
public class SurveyReport {

	// Annotation specifying the primary key
	@Id
	@Column(name = "ClaimId", length = 50, nullable = false)
	private String claimId;
	
	@Column(name = "PolicyNo", length = 50)
	private String policyNo;
	
	@PositiveOrZero(message = "Labour charges cannot be negative")
	private int labourCharges;
	
	@PositiveOrZero(message = "Part cost cannot be negative")
	private int partsCost;
	
	@PositiveOrZero(message = "Policy class cannot be negative")
	private int policyclass;
	
	@Column(name = "DepreciationCost")
	@PositiveOrZero(message = "Depreciation cost cannot be negative")
	private int depreciationCost;

	@PositiveOrZero(message = "Total amount cannot be negative")
	private int totalamount;


	// Getters & Setters ...
	public String getClaimId() {
		return claimId;
	}

	public void setClaimId(String claimId) {
		// This keyword refers 
        // to parent instance itself
		this.claimId = claimId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public int getLabourCharges() {
		return labourCharges;
	}

	public void setLabourCharges(int loabourCharges) {
		this.labourCharges = loabourCharges;
	}

	public int getPartsCost() {
		return partsCost;
	}

	public void setPartsCost(int partsCost) {
		this.partsCost = partsCost;
	}

	public int getPolicyclass() {
		return policyclass;
	}

	public void setPolicyclass(int policyclass) {
		this.policyclass = policyclass;
	}

	public int getDepreciationCost() {
		return depreciationCost;
	}

	public void setDepreciationCost(int depreciationCost) {
		this.depreciationCost = depreciationCost;
	}

	public int getTotalamount() {
		return totalamount;
	}

	public void setTotalamount(int totalamount) {
		this.totalamount = totalamount;
	}

	// toString() method
	@Override
	public String toString() {
		return "SurveyReport [claimId=" + claimId + ", policyNo=" + policyNo + ", labourCharges=" + labourCharges
				+ ", partsCost=" + partsCost + ", policyclass=" + policyclass + ", depreciationCost=" + depreciationCost
				+ ", totalamount=" + totalamount + "]";
	}


	// Constructor
	public SurveyReport() {
		super();
	}

	public SurveyReport(String claimId, String policyNo, int labourCharges, int partsCost, int policyclass, int depreciationCost) {
		this.claimId = claimId;
		this.policyNo = policyNo;
		this.labourCharges = labourCharges;
		this.partsCost = partsCost;
		this.policyclass = policyclass;
		this.depreciationCost = depreciationCost;
	}

	@Override
	// equals() method
	public boolean equals(Object o) {
		// Check if the compared object is the same instance
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		SurveyReport report = (SurveyReport) o;
		return labourCharges == report.labourCharges && partsCost == report.partsCost && policyclass == report.policyclass && depreciationCost == report.depreciationCost && totalamount == report.totalamount && Objects.equals(claimId, report.claimId) && Objects.equals(policyNo, report.policyNo);
	}

}