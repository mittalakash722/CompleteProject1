package com.claims.claimsManagementSystem.DAO;

import com.claims.claimsManagementSystem.DTO.SurveyReportDTO;
import com.claims.claimsManagementSystem.exceptions.CustomException;
import org.springframework.http.ResponseEntity;

import com.claims.claimsManagementSystem.surveyReport.SurveyReport;

public interface SurveyReportDAO {

    // Method for inserting a survey report
	SurveyReport SurveyInsert(SurveyReportDTO surveyReportDTO) throws CustomException;

    // Method for retrieving a survey report by its ID
	SurveyReportDTO getSurveyById(String claimId) throws CustomException;
	
    // Method for updating a survey report
	public SurveyReport updateSurvey(String claimId, SurveyReportDTO surveyReportDTO) throws CustomException;

}
