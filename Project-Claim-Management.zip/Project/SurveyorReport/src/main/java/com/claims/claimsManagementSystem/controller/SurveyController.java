package com.claims.claimsManagementSystem.controller;
import java.util.HashMap;

// importing necessary libraries
import com.claims.claimsManagementSystem.DTO.SurveyReportDTO;
import com.claims.claimsManagementSystem.exceptions.CustomException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.claims.claimsManagementSystem.DAOimp.SurveyReportDAOimp;
import com.claims.claimsManagementSystem.surveyReport.SurveyReport;

import java.util.Map;

import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;



@RestController
@CrossOrigin(origins = "http://localhost:4200",allowedHeaders = "*")
@Validated
public class SurveyController {
	@Autowired
	SurveyReportDAOimp srvyimp;

	
	 @PostMapping("/api/surveyors/new")
	    public ResponseEntity add(@RequestBody SurveyReportDTO surveyReportDTO) throws CustomException {

	        // Your logic for saving the survey report
	        SurveyReport res = srvyimp.SurveyInsert(surveyReportDTO);
	        if (res == null) {
	            throw new RuntimeException("Invalid data");
	        }
	        return ResponseEntity.status(HttpStatus.CREATED).build();
	    }

	 @ExceptionHandler(MethodArgumentNotValidException.class)
	    public ResponseEntity<Map<String, String>> handleValidationException(MethodArgumentNotValidException ex) {
	        BindingResult result = ex.getBindingResult();
	        Map<String, String> errors = new HashMap<>();
	        for (FieldError error : result.getFieldErrors()) {
	            errors.put(error.getField(), error.getDefaultMessage());
	        }
	        return ResponseEntity.badRequest().body(errors);
	    }
	
	//Annotation Handling Post Request
//	@PostMapping("/api/surveyors/new")
//	SurveyReport add(@Valid @RequestBody SurveyReport report) {
//		SurveyReport res = srvyimp.SurveyInsert(report);
//		if (res == null) {
//			throw new RuntimeException("Invalid data");
//		}
//		return res;
//
//	}
	
	//Annotation Handling Get Request
	@GetMapping("/api/surveyors/get/{claimId}")
	SurveyReportDTO get(@PathVariable String claimId) throws CustomException {
		return srvyimp.getSurveyById(claimId);
	}

	//Annotation Handling Put Request
	@PutMapping("/api/surveyors/update/{claimId}")
	public SurveyReport updateEmployee(@PathVariable String claimId, @RequestBody SurveyReportDTO surveyReportDTO) throws CustomException {

		return srvyimp.updateSurvey(claimId, surveyReportDTO);

	}
}
