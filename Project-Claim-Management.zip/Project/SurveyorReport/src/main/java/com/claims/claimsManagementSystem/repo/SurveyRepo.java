package com.claims.claimsManagementSystem.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.claims.claimsManagementSystem.surveyReport.SurveyReport;

//Repository interface for SurveyReport entity
public interface SurveyRepo extends JpaRepository<SurveyReport, String> {

	// Method to find a SurveyReport by claimId
	SurveyReport findSurveyReportByClaimId(String id);

}
