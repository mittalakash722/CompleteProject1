package com.claims.claimsManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ApplicationContext;

@SpringBootApplication  // same as @Configuration @EnableAutoConfiguration @ComponentScan
@EnableEurekaClient
@EnableFeignClients
public class SurveyorReportApplication {

	// Main Method
	public static void main(String[] args) {
		
		ApplicationContext ctx = SpringApplication.run(SurveyorReportApplication.class, args);
	}

}
