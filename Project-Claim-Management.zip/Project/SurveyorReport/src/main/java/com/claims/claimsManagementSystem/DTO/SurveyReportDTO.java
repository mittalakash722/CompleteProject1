package com.claims.claimsManagementSystem.DTO;

// Data Transfer Object (DTO) class for Survey Report
public class SurveyReportDTO {

	private String ClaimID;

	private String policyNo;

	private int LabourCharges;

	private int partsCost;

	private int policyClass;

	private int depreciationCost;

	private int totalAmount;

	public SurveyReportDTO(String claimID, String policyNo, int labourCharges, int partsCost, int policyClass, int depreciationCost) {
		ClaimID = claimID;
		this.policyNo = policyNo;
		LabourCharges = labourCharges;
		this.partsCost = partsCost;
		this.policyClass = policyClass;
		this.depreciationCost = depreciationCost;
	}

	public SurveyReportDTO()
	{

	}
	// Getters and Setters ...

	public String getClaimID() {
		return ClaimID;
	}

	public void setClaimID(String claimID) {
		ClaimID = claimID;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public int getLabourCharges() {
		return LabourCharges;
	}

	public void setLabourCharges(int laborCharges) {
		LabourCharges = laborCharges;
	}

	public int getPartsCost() {
		return partsCost;
	}

	public void setPartsCost(int partsCost) {
		this.partsCost = partsCost;
	}

	public int getPolicyClass() {
		return policyClass;
	}

	public void setPolicyClass(int policyClass) {
		this.policyClass = policyClass;
	}

	public int getDepreciationCost() {
		return depreciationCost;
	}

	public void setDepreciationCost(int depreciationCost) {
		this.depreciationCost = depreciationCost;
	}

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}

	@Override
	public String toString() {
		return "SurveyReportDTO{" +
				"ClaimID='" + ClaimID + '\'' +
				", policyNo='" + policyNo + '\'' +
				", LaborCharges=" + LabourCharges +
				", partsCost=" + partsCost +
				", policyClass=" + policyClass +
				", depreciationCost=" + depreciationCost +
				", totalAmount=" + totalAmount +
				'}';
	}
}
