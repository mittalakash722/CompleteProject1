package com.claims.claimsManagementSystem.DAOimp;

import com.claims.claimsManagementSystem.repo.SurveyRepo;
import com.claims.claimsManagementSystem.surveyReport.SurveyReport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
class SurveyReportDAOimpTest {

    @Mock
    SurveyRepo surveyRepo;
    @InjectMocks
    SurveyReportDAOimp  surveyReportDAOimp;

    SurveyReport surveyReport;
    SurveyReport updatedsurveyReport;
    @BeforeEach
    void setUp()
    {
     surveyReport = new SurveyReport("CL20232032", "PL02345", 200, 5000,100 , 1);

    }
    @Test
    void surveyInsert() {
        when(surveyRepo.save(surveyReport)).thenReturn(surveyReport);
        SurveyReport report=surveyReportDAOimp.SurveyInsert(surveyReport);
        assertNotNull(report);
    }

    @Test
    void getSurveyById() {
        when(surveyRepo.findSurveyReportByClaimId("CL20232032")).thenReturn(surveyReport);
        SurveyReport report=surveyReportDAOimp.getSurveyById("CL20232032");
        assertNotNull(report);
    }

    @Test
    void updateSurvey() {
        when(surveyRepo.findSurveyReportByClaimId("CL20232032")).thenReturn(surveyReport);
        when(surveyRepo.save(surveyReport)).thenReturn(surveyReport);
        updatedsurveyReport=new SurveyReport("CL20232032", "PL02345", 300, 5000,300 , 1);
        SurveyReport report=surveyReportDAOimp.updateSurvey("CL20232032",updatedsurveyReport);
        assertEquals(updatedsurveyReport,report);
    }
}