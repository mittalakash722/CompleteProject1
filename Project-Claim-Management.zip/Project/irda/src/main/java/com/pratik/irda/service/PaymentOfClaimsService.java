package com.pratik.irda.service;

import com.pratik.irda.DTO.ClaimDetailsDTO;
import com.pratik.irda.entities.PaymentOfClaims;
import com.pratik.irda.DTO.PaymentStatus;
import com.pratik.irda.microServices.InsuranceCompanyMicroService;
import com.pratik.irda.repo.PaymentOfClaimsRepo;

import java.time.Month;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentOfClaimsService {

    @Autowired
    PaymentOfClaimsRepo  paymentOfClaimsRepo;

	@Autowired
	InsuranceCompanyMicroService insuranceCompanyMicroService;

    public List<PaymentStatus> getPaymentOfClaims(String month,int year)
	{ 	
    	if((month.equalsIgnoreCase("January")) || (month.equalsIgnoreCase("Febuary")) || (month.equalsIgnoreCase("March")) || (month.equalsIgnoreCase("April")) || (month.equalsIgnoreCase("May")) || (month.equalsIgnoreCase("June")) || (month.equalsIgnoreCase("July")) || (month.equalsIgnoreCase("August")) || (month.equalsIgnoreCase("September")) || (month.equalsIgnoreCase("October")) || (month.equalsIgnoreCase("November")) || (month.equalsIgnoreCase("December"))) {
			
	    	    List<PaymentOfClaims> report=paymentOfClaimsRepo.getPaymentOfClaimsByMonthAndYear(month,year);
	    		Map<String, Integer> map=new HashMap<>();
	    		List<PaymentStatus> paymentStatusList=new ArrayList<>();
	        	for (PaymentOfClaims p:report)
	        	{
	        		if(map.containsKey(p.getMonth()))
	        		{
	        			int updatedPayment=map.get(p.getMonth())+p.getPayment();
	        			map.put(p.getMonth(),updatedPayment);
	        		}
	        		else
	        		{
	                map.put(p.getMonth(),p.getPayment());
	        		}
	        	}
	        	
	        	for(Map.Entry<String,Integer> e:map.entrySet())
	        	{
	        		PaymentStatus payemntStatus=new PaymentStatus(e.getKey(),e.getValue());
	        		
	            	paymentStatusList.add(payemntStatus );
	        	}
	        	return paymentStatusList;
	       
		}
    	else
    	{
			throw new RuntimeException("Invalid Month");
    	}
}
    
    public List<PaymentOfClaims> pullPaymentsOfClaims(String month,int year)
   
    {
		List<ClaimDetailsDTO> paymentOfClaims=insuranceCompanyMicroService.getClaims();
		List<PaymentOfClaims> paymentOfClaimsList=new ArrayList<>();
		for(ClaimDetailsDTO claimDetailsDTO:paymentOfClaims)
		{
			String date=""+claimDetailsDTO.getDateOfAccident();
			String [] dateSplit=date.split("-");
			int yearGet = Integer.parseInt(dateSplit[0]);
			String monthGet= Month.of(Integer.parseInt(dateSplit[1])).toString().toLowerCase();
			if (monthGet.equalsIgnoreCase(month) && year==yearGet) {
				PaymentOfClaims payment = new PaymentOfClaims();
				payment.setReportId(generateReportId(monthGet, yearGet));
				payment.setMonth(monthGet);
				payment.setYear(yearGet);
				payment.setPayment(claimDetailsDTO.getAmtApprovedBySurveyor());
				paymentOfClaimsList.add(payment);
			}
		}
    	return paymentOfClaimsRepo.saveAll(paymentOfClaimsList);
    }
	String generateReportId(String month,int year)
	{
		String yr=String.valueOf(year);
		return "PS"+month.substring(0,3)+yr.substring(yr.length()-2);
	}

}
