package com.pratik.irda.DTO;

public class PaymentStatus {
	private String month;
	private int Payement;
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getPayement() {
		return Payement;
	}
	public void setPayement(int payement) {
		Payement = payement;
	}
	public PaymentStatus(String month, int payement) {
		super();
		this.month = month;
		Payement = payement;
	}
	public PaymentStatus() {
		super();
	}
	

}
