package com.pratik.irda.service;

import com.pratik.irda.entities.ClaimStatus;
import com.pratik.irda.entities.PendingStatusReport;
import com.pratik.irda.repo.ClaimStatusRepo;
import com.pratik.irda.repo.PendingStatusReportRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PendingStatusReportService {

       // PendingStatusReport getPending
	
}
