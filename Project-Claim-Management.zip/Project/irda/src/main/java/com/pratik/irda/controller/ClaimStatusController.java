package com.pratik.irda.controller;

import java.util.List;

import com.pratik.irda.entities.PendingStatusReport;
import com.pratik.irda.exceptions.CustomException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.pratik.irda.entities.ClaimStatus;
import com.pratik.irda.service.ClaimStatusService;
@CrossOrigin("http://localhost:4200")

@RestController
public class ClaimStatusController {
    @Autowired
    ClaimStatusService claimStatusService;
    @GetMapping("irda/claimStatus/repot/{month}/{year}")
    List<ClaimStatus> getClaimStatusByMonthYear(@PathVariable String month,@PathVariable int year)
    {
        return claimStatusService.getClaimStatusByMonthYear(month,year);
    }
    
    @PostMapping("irda/claimStatus/pull/{month}/{year}")
    public ResponseEntity<List<PendingStatusReport>> pullStatusOfClaimsByMonth(@PathVariable String month, @PathVariable int year) throws CustomException {
        List<PendingStatusReport> claimStatus=claimStatusService.pullStatusOfClaimsByMonthAndYear(month,year);
    	if (claimStatus.isEmpty())
        {
            throw  new CustomException("no claims Exist");
        }
        return ResponseEntity.status(HttpStatus.OK).body(claimStatus);
    }
    
}
