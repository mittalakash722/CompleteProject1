package com.pratik.irda.microServices;

import com.pratik.irda.DTO.ClaimDetailsDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.*;
@FeignClient("INSURANCECOMPANY")
public interface InsuranceCompanyMicroService {
    @GetMapping("/api/claims")
    List<ClaimDetailsDTO> getClaims();
}
