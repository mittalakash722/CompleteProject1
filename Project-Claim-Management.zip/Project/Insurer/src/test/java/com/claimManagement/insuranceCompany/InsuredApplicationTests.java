package com.claimManagement.insuranceCompany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
//import com.claimManagement.insuranceCompany.daoImpTest.*;
@SpringBootTest
class InsuredApplicationTests {

	@Test
	void contextLoads() {

	}


}
