package com.claimManagement.insuranceCompany.serviceImp;

import com.claimManagement.insuranceCompany.microserviceCRUD.ClaimDetailsMicroService;
import com.claimManagement.insuranceCompany.service.ClaimService;
import com.claimManagement.insuranceCompany.DTO.ClaimDetailsDTO;
import com.claimManagement.insuranceCompany.entities.ClaimDetails;
import com.claimManagement.insuranceCompany.entities.Policy;
import com.claimManagement.insuranceCompany.entities.Surveyor;
import com.claimManagement.insuranceCompany.exceptions.CustomException;
import com.claimManagement.insuranceCompany.repositories.ClaimRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClaimServiceImp implements ClaimService {

    @Autowired
    ClaimRepository claimRepository;


    @Autowired
    ClaimDetailsMicroService claimDetailsMicroService;



    // Add a new claim.
    @Override
    public ResponseEntity<String> AddNewClaim(ClaimDetailsDTO claimDetailsDTO){


       String claimDetails1= claimDetailsMicroService.newClaim(claimDetailsDTO).getBody();

        return ResponseEntity.status(HttpStatus.CREATED).body(claimDetails1);

    }

    //update claim by setting claim status.
    @Override
    public ClaimDetails UpdateByClaimID(String claimId,ClaimDetailsDTO claimDetailsDTO) throws CustomException {
        ClaimDetailsDTO claimDetailsById=claimDetailsMicroService.getClaimById(claimId).getBody();
        if (claimDetailsById==null)
        {
            throw new CustomException("No Claim exist with claimId: "+claimId);
        }
        else if (claimDetailsById.getClaimStatus().equals("closed")) {
            throw new CustomException("Claim is closed . Unable to update");
        }

        claimDetailsById.setWithdrawClaim(claimDetailsDTO.isWithdrawClaim());
        claimDetailsById.setClaimStatus("closed");
        return claimRepository.save(toEntity(claimDetailsById));
    }

    //Entity to DTO convertion
    public ClaimDetailsDTO toDTO(ClaimDetails claimDetails) {
        ClaimDetailsDTO claimDetailsDto = new ClaimDetailsDTO();

        claimDetailsDto.setClaimId(claimDetails.getClaimId());
        claimDetailsDto.setPolicyNo(claimDetails.getPolicy().getPolicyNo());
        claimDetailsDto.setEstimatedLoss(claimDetails.getEstimatedLoss());
        claimDetailsDto.setDateOfAccident(claimDetails.getDateOfAccident());
        claimDetailsDto.setClaimStatus(claimDetails.getClaimStatus());
        claimDetailsDto.setSurveyorId(claimDetails.getSurveyor().getSurveyorId());
        claimDetailsDto.setAmtApprovedBySurveyor(claimDetails.getAmtApprovedBySurveyor());
        claimDetailsDto.setInsuranceCompanyApproval(claimDetails.isInsuranceCompanyApproval());
        claimDetailsDto.setWithdrawClaim(claimDetails.isWithdrawClaim());
        claimDetailsDto.setSurveyorfees(claimDetails.getSurveyorfees());

        return claimDetailsDto;
    }

    //DTO to Entity Conversion
    public ClaimDetails toEntity(ClaimDetailsDTO claimDetailsDto) {
        ClaimDetails claimDetails = new ClaimDetails();

        claimDetails.setClaimId(claimDetailsDto.getClaimId());
        claimDetails.setEstimatedLoss(claimDetailsDto.getEstimatedLoss());
        claimDetails.setDateOfAccident(claimDetailsDto.getDateOfAccident());
        claimDetails.setClaimStatus(claimDetailsDto.getClaimStatus());
        claimDetails.setAmtApprovedBySurveyor(claimDetailsDto.getAmtApprovedBySurveyor());
        claimDetails.setInsuranceCompanyApproval(claimDetailsDto.isInsuranceCompanyApproval());
        claimDetails.setWithdrawClaim(claimDetailsDto.isWithdrawClaim());
        claimDetails.setSurveyorfees(claimDetailsDto.getSurveyorfees());

        Policy policy = new Policy();
        policy.setPolicyNo(claimDetailsDto.getPolicyNo());
        claimDetails.setPolicy(policy);

        Surveyor surveyor = new Surveyor();
        surveyor.setSurveyorId(claimDetailsDto.getSurveyorId());
        claimDetails.setSurveyor(surveyor);

        return claimDetails;
    }

}
