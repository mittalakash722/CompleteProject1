package com.claimManagement.insuranceCompany.microserviceCRUD;

import com.claimManagement.insuranceCompany.DTO.ClaimDetailsDTO;
import com.claimManagement.insuranceCompany.entities.ClaimDetails;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
@FeignClient(value = "INSURANCECOMPANY")
public interface ClaimDetailsMicroService {

    @PostMapping("/api/claims/new")
    ResponseEntity<String> newClaim(ClaimDetailsDTO claimDetailsDTO);
    @GetMapping("/api/claims/id/{claimId}")
    ResponseEntity<ClaimDetailsDTO> getClaimById(@PathVariable String claimId);
}
