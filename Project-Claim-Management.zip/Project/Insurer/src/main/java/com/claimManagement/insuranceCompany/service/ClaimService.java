package com.claimManagement.insuranceCompany.service;

import com.claimManagement.insuranceCompany.DTO.ClaimDetailsDTO;
import com.claimManagement.insuranceCompany.entities.ClaimDetails;
import com.claimManagement.insuranceCompany.exceptions.CustomException;
import org.springframework.http.ResponseEntity;


import java.util.List;

public interface ClaimService {
    ResponseEntity<String> AddNewClaim(ClaimDetailsDTO claimDetailsDTO) throws CustomException;
    ClaimDetails UpdateByClaimID(String claimId,ClaimDetailsDTO claimDetailsDTO) throws CustomException;

}

