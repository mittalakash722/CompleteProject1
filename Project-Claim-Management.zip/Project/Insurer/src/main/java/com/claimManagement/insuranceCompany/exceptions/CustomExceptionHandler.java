package com.claimManagement.insuranceCompany.exceptions;

import com.claimManagement.insuranceCompany.exceptions.CustomException;

import javax.validation.ConstraintViolationException;

import feign.FeignException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;

@RestControllerAdvice
public class CustomExceptionHandler {

    //Handles Exception when no body provided while posting data.
    @ExceptionHandler({HttpMessageNotReadableException.class})
    protected ResponseEntity<Object> handleHttpMessageNotReadableException(Exception ex, WebRequest request) {
        String error = "Request body is missing or invalid.";
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
    }
    //Handles Exception when invalid API is called.
    @ExceptionHandler({HttpRequestMethodNotSupportedException.class})
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupportedException(Exception ex, WebRequest request) {
        String error = "Requested API is missing or invalid.";
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
    }
    @ExceptionHandler(NoHandlerFoundException.class)
    protected ResponseEntity<Object> handleNoHandlerFoundException(Exception ex, WebRequest request) {
        String error = "Requested API is missing or invalid.";
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
    }
//    @ExceptionHandler({ConstraintViolationException.class})
//    protected ResponseEntity<Object> handleConstraintViolationException(Exception ex, WebRequest request) {
//        String error = "Costraint Error check the fields entered.\n"+ex.getMessage();
//
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
//    }

    //Handles custom Exception
    @ExceptionHandler({CustomException.class})
    protected ResponseEntity<Object> handlingCustomException(CustomException e)
    {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
    }
    @ExceptionHandler(FeignException.class)
    protected ResponseEntity<Object> handlingFeignException(FeignException e)
    {
        String msg=e.getMessage();
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(msg.substring(msg.lastIndexOf(":") + 1));
    }

}
