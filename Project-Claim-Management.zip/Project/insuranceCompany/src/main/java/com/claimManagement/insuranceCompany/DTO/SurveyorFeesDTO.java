package com.claimManagement.insuranceCompany.DTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SurveyorFeesDTO {
    private String claimId;
    private String surveyorId;
    private int surveyorFee;
    private String surveyorName;
    private int estimatedLimit;
}
