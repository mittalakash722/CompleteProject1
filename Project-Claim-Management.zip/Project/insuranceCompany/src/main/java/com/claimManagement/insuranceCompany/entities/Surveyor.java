package com.claimManagement.insuranceCompany.entities;

import org.hibernate.annotations.Cascade;
import org.hibernate.validator.constraints.br.CPF;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.util.List;
import java.util.Objects;

@Entity
public class Surveyor {
    @Id
    @Column(name = "surveyorId",length = 10)
    private String surveyorId;

    @NotNull
    @Column(length = 10)
    private String firstName;

    @NotNull
    @Column(length = 10)
    private String lastName;

    @NotNull
    @Positive
    private int estimateLimit;

    @OneToMany(mappedBy = "surveyor")
    private List<ClaimDetails> ClaimDetails;
    public Surveyor() {
    }

    public Surveyor(String surveyorId, String firstName, String lastName, int estimateLimit) {
        this.surveyorId = surveyorId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.estimateLimit = estimateLimit;
    }

    public String getSurveyorId() {
        return surveyorId;
    }

    public void setSurveyorId(String surveyorId) {
        this.surveyorId = surveyorId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getEstimateLimit() {
        return estimateLimit;
    }

    public void setEstimateLimit(int estimateLimit) {
        this.estimateLimit = estimateLimit;
    }

    @Override
    public String toString() {
        return "Surveyor{" +
                "surveyorId=" + surveyorId +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", estimateLimit=" + estimateLimit +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Surveyor surveyor = (Surveyor) o;
        return surveyorId == surveyor.surveyorId && estimateLimit == surveyor.estimateLimit && Objects.equals(firstName, surveyor.firstName) && Objects.equals(lastName, surveyor.lastName);
    }

}
