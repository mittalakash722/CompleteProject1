package com.claimManagement.insuranceCompany.serviceImp;

import com.claimManagement.insuranceCompany.DTO.SurveyorFeesDTO;
import com.claimManagement.insuranceCompany.service.ClaimService;
import com.claimManagement.insuranceCompany.DTO.ClaimDetailsDTO;
import com.claimManagement.insuranceCompany.DTO.PolicyDTO;
import com.claimManagement.insuranceCompany.DTO.SurveyorDTO;
import com.claimManagement.insuranceCompany.entities.ClaimDetails;
import com.claimManagement.insuranceCompany.entities.Policy;
import com.claimManagement.insuranceCompany.entities.Surveyor;
import com.claimManagement.insuranceCompany.exceptions.CustomException;
import com.claimManagement.insuranceCompany.repositories.ClaimRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Constants;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClaimServiceImp implements ClaimService {

    @Autowired
    ClaimRepository claimRepository;

    @Autowired
    PolicyServiceImp policyServiceImp;

    @Autowired
    SurveyorServiceImp surveyorServiceImp;

    // Generate claim ID based on the policy number and the year of the accident.
    static   String generateClaimId(ClaimDetailsDTO claimDetails)
    {

        String policyNo = claimDetails.getPolicyNo();
        String year = String.valueOf(claimDetails.getDateOfAccident().getYear());
        
        return "CL" +
                policyNo.substring(policyNo.length()-4) +
                year;
    }

    // Retrieve all claims
    @Override
    public List<ClaimDetailsDTO> getClaims() throws CustomException {
        List<ClaimDetails> claimDetails=claimRepository.findAll();
        //Throws Exception when no claims exists.
        if (claimDetails.isEmpty())
        {
            throw new CustomException("No claims Exist");
        }
        return claimDetails.stream().map((x)-> toDTO(x)).collect(Collectors.toList());
    }

    // Add a new claim.
    @Override
    public ClaimDetails AddNewClaim(ClaimDetailsDTO claimDetailsDTO) throws CustomException {

        //System.out.println("getting request data:"+claimDetailsDTO);



        String claimId=generateClaimId(claimDetailsDTO);
        if(claimRepository.existsClaimDetailsByClaimId(claimId) )
        {
            throw new CustomException( "MaximumClaimLimitReachedException: Only one claim in a year");
        }
        claimDetailsDTO.setClaimStatus("open");
        claimDetailsDTO.setClaimId(claimId);
        claimDetailsDTO.setSurveyorId("N/A");

        ClaimDetails claimDetails=toEntity(claimDetailsDTO);

        System.out.println(claimDetails);

        ClaimDetails claimDetails1=claimRepository.save(claimDetails);;
       if (claimDetails1==null)
       {
           throw new RuntimeException();
       }
        System.out.println("or:"+claimDetails1);
        return  claimDetails1;

    }

    //update claim by setting claim status.
    @Override
    public ClaimDetails UpdateByClaimID(String claimId,ClaimDetailsDTO claimDetailsDTO) throws CustomException {

        // If a claim with the same ID already exists, throw an exception.

        if(!claimRepository.existsClaimDetailsByClaimId(claimId) )
        {
            throw new CustomException( "claim doesnot exist associated with id - "+claimId);
        }

        ClaimDetails claimDetails=claimRepository.findById(claimId).get();
        if(claimDetails.getClaimStatus().equals("closed"))
        {
            throw new CustomException("Requested claim is closed.unable to update claim");
        }


        if( claimDetailsDTO.getClaimStatus()!=null)
        {
            claimDetails.setClaimStatus(claimDetailsDTO.getClaimStatus());
        }
        if (claimDetailsDTO.isInsuranceCompanyApproval())
        {
            claimDetails.setInsuranceCompanyApproval(claimDetailsDTO.isInsuranceCompanyApproval());
        }
        claimDetails.setAmtApprovedBySurveyor(claimDetails.getEstimatedLoss()-claimDetails.getSurveyorfees());

        System.out.println(claimDetails);
        return claimRepository.save(claimDetails);
    }

    //Entity to DTO convertion
    @Override
    public ClaimDetailsDTO getClaimById(String id) throws CustomException {
        Optional<ClaimDetails> claimDetails= Optional.of(claimRepository.findById(id).orElseThrow(() -> new CustomException("No Claim found with id - "+id)));
        return  toDTO(claimDetails.get());
    }

    @Override
    public SurveyorFeesDTO releaseSurveyorsFee(String claimId) throws CustomException {
        ClaimDetails claimDetails=claimRepository.findById(claimId).get();
        SurveyorDTO surveyorDTO;

        // Retrieve the policy associated with the claim.
        int estimateLimit=claimDetails.getEstimatedLoss();

        // Retrieve the surveyor with the appropriate estimate limit.
        surveyorDTO= surveyorServiceImp.getSurveyorByEstimateLimit(estimateLimit);

        Surveyor surveyor= SurveyorServiceImp.toEntity(surveyorDTO);

        claimDetails.setSurveyor(surveyor);
        // Determine the surveyor fee based on the estimated loss.
        if(claimDetails.getEstimatedLoss()>=5000 && claimDetails.getEstimatedLoss()<10000)
        {
            claimDetails.setSurveyorfees(1000);
        }
        else if(claimDetails.getEstimatedLoss()>=10000 && claimDetails.getEstimatedLoss()<20000)
        {
            claimDetails.setSurveyorfees(2000);
        }
        else if(claimDetails.getEstimatedLoss()>=20000 && claimDetails.getEstimatedLoss()<70000)
        {
            claimDetails.setSurveyorfees(7000);
        }
        else
        {
            throw  new CustomException("No Surveyor Available  ");
        }

        claimRepository.save(claimDetails);
        SurveyorFeesDTO surveyorFeesDTO=new SurveyorFeesDTO().builder()
                .claimId(claimDetails.getClaimId())
                .surveyorId(claimDetails.getSurveyor().getSurveyorId())
                .surveyorName(claimDetails.getSurveyor().getFirstName()+" "+claimDetails.getSurveyor().getLastName())
                .surveyorFee(claimDetails.getSurveyorfees())
                .estimatedLimit(claimDetails.getEstimatedLoss())
                .build();
        return surveyorFeesDTO;
    }
    public ClaimDetails UpdateByClaimAmnt(String claimId, int amnt) throws CustomException {
        Optional<ClaimDetails> claimDetailsOptional= Optional.of(claimRepository.findById(claimId).orElseThrow(() -> new CustomException("No Claim found with id - "+claimId)));
        ClaimDetails claimDetails=claimDetailsOptional.get();
        return claimRepository.save(claimDetails);
    }

    public ClaimDetailsDTO toDTO(ClaimDetails claimDetails) {
        ClaimDetailsDTO claimDetailsDto = new ClaimDetailsDTO();

        claimDetailsDto.setClaimId(claimDetails.getClaimId());
        claimDetailsDto.setPolicyNo(claimDetails.getPolicy().getPolicyNo());
        claimDetailsDto.setEstimatedLoss(claimDetails.getEstimatedLoss());
        claimDetailsDto.setDateOfAccident(claimDetails.getDateOfAccident());
        claimDetailsDto.setClaimStatus(claimDetails.getClaimStatus());
        claimDetailsDto.setSurveyorId(claimDetails.getSurveyor().getSurveyorId());
        claimDetailsDto.setAmtApprovedBySurveyor(claimDetails.getAmtApprovedBySurveyor());
        claimDetailsDto.setInsuranceCompanyApproval(claimDetails.isInsuranceCompanyApproval());
        claimDetailsDto.setWithdrawClaim(claimDetails.isWithdrawClaim());
        claimDetailsDto.setSurveyorfees(claimDetails.getSurveyorfees());

        return claimDetailsDto;
    }

    //DTO to Entity Conversion
    public ClaimDetails toEntity(ClaimDetailsDTO claimDetailsDto) {
        ClaimDetails claimDetails = new ClaimDetails();

        claimDetails.setClaimId(claimDetailsDto.getClaimId());
        claimDetails.setEstimatedLoss(claimDetailsDto.getEstimatedLoss());
        claimDetails.setDateOfAccident(claimDetailsDto.getDateOfAccident());
        claimDetails.setClaimStatus(claimDetailsDto.getClaimStatus());
        claimDetails.setAmtApprovedBySurveyor(claimDetailsDto.getAmtApprovedBySurveyor());
        claimDetails.setInsuranceCompanyApproval(claimDetailsDto.isInsuranceCompanyApproval());
        claimDetails.setWithdrawClaim(claimDetailsDto.isWithdrawClaim());
        claimDetails.setSurveyorfees(claimDetailsDto.getSurveyorfees());

        Policy policy = new Policy();
        policy.setPolicyNo(claimDetailsDto.getPolicyNo());
        claimDetails.setPolicy(policy);

        Surveyor surveyor = new Surveyor();
        surveyor.setSurveyorId(claimDetailsDto.getSurveyorId());
        claimDetails.setSurveyor(surveyor);

        return claimDetails;
    }


}
