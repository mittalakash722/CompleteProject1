package com.claimManagement.insuranceCompany.exceptions;

public class CustomException extends Exception{
    public CustomException(String s)
    {
        super(s);
    }
}
